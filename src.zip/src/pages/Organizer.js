import React from 'react'

const Organizer = ({organizer}) => {
  return (
    <div className="organizer">
      test
      {/* <div className="profile-sidebar">
        <img className="profile-image" src={foundObject?.poster?.url} />
      </div>
      <div className="profile-main">
        <h2 className="profile-name">{foundObject?.title}</h2>
        <div style={{ borderBottom: "1px solid black" }}>
          <p
            className="profile-body"
            dangerouslySetInnerHTML={{
              __html: foundObject?.event_details?.description,
            }}
          ></p>
        </div>
        <div className="location" style={{ color: "" }}>
          <RiLocationLine size={24} color="#007bff" />
          <span>123 Main Street, City, Country</span>
        </div>
      </div> */}
    </div>
  )
}

export default Organizer