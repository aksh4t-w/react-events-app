import logo from './logo.svg';
import './App.css';
import React, { useEffect, useState } from 'react'
import Events from './components/Events';
import { BsMoonFill } from 'react-icons/bs';
import 'bootstrap/dist/css/bootstrap.min.css';
import { HelmetProvider } from "react-helmet-async";
import {BrowserRouter as Router,Routes,
  Route,
  Link,
  NavLink,
  useNavigate,
} from "react-router-dom";
import Organizer from './pages/Organizer';

function App() {
  const [darkMode, setDarkMode] = useState(false);

  const toggleDarkMode = () => {
    setDarkMode((prevState) => !prevState);
  };

  return (
    <div className={`App ${darkMode ? 'dark-mode' : ''}`}>
      <HelmetProvider>
        <Events darkMode={darkMode}/>
        <button className="dark-mode-toggle" onClick={toggleDarkMode}>
      <BsMoonFill size={20} className="moon-icon" />
      </button>
      </HelmetProvider>
      

      {/* <Router>
        <Routes>
          <Route exact path="/" element={<Events/>}/>
          <Route exact path="/organizer/:uid" element={<Organizer />}/>
        </Routes>
      </Router> */}

    </div>
  );
}

export default App;
